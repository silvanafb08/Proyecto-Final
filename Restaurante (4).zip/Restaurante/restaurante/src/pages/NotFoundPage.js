import React from 'react'

export default function NotFoundPage() {
  return (
    <div>
        <h1>NotFoundPage</h1></div>
  )
}
