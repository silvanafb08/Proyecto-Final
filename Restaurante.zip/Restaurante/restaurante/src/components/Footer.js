import React from 'react'

export default function Footer() {
  return (
    <div >
        
  <footer class="footer">

  <div class="text-center p-3" style={{backgroundColor: "rgb(63,83,115)"}}>
    <label class= "footer__p" style={{color :"white"}}>Creacion de camila, luis y silvana</label>
  </div>

</footer>
  
</div>
  )
}
