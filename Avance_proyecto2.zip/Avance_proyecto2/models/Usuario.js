const mongoose = require('mongoose');
const Schema = mongoose.Schema;


const usuariosSchema = new Schema({

    USU_CODIGO:{
        type:String,
        trim:true,
        unique:true
    },
    USU_NOMBRE:{
        type:String
    },
    USU_APELLIDO1:{
        type:String,
        trim:true
    },
    USU_APELLIDO2:{
        type:String,
        trim:true
    },
    USU_TELEF1:{
        type:String,
        trim:true
    },
    USU_TELEF2:{
        type:String,
        trim:true
    },
    USU_CONTRA:{
        type:String,
        trim:true
    },
    USU_PRIVI:{
        SISTEMA:{
            type:String
        },
        SEGURIDAD:{
            type:String
        },
        RESTAURNATE:{
            type:String
        },
        CUENTAS:{
            type:String
        },
    },
    USU_LOGIN:{
        CORREO:{
            type:String,
            trim:true,
            unique:true,
            lowercase:true
        },
        CONTRASENA:{
            type:String,
        }
    }
});


mongoose.pluralize(null);
module.exports = mongoose.model('Usuario', usuariosSchema);